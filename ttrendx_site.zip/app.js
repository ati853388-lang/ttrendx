document.addEventListener('DOMContentLoaded',()=>{
  const grid=document.getElementById('productsGrid');
  const products=[
    {title:'قاب سیلیکونی iPhone 15',price:'799000'},
    {title:'iPhone 15 Pro',price:'43990000'}
  ];
  products.forEach(p=>{
    const div=document.createElement('div');
    div.className='product-card';
    div.innerHTML=`<h3>${p.title}</h3><p>${p.price} تومان</p>`;
    grid.appendChild(div);
  });
});